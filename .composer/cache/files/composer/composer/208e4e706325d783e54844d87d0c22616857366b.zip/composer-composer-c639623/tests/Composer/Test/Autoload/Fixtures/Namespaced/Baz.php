<?php

namespace Namespaced;

class Baz
{
    public static $loaded = true;
}
