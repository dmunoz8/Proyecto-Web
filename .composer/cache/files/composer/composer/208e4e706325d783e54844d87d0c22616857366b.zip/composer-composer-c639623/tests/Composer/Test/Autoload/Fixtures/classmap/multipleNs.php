<?php
namespace Alpha {
    class A {}
    class B {}
}

namespace {
    class A {}
}

namespace Be \ ta {
    class A {}
    class B {}
}
