<?php
// @deprecated Load new class and alias.
class_exists('Cake\Http\Client\Response');
