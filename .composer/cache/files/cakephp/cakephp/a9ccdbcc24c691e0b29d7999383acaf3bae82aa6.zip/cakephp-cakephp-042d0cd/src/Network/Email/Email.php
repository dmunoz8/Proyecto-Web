<?php
// @deprecated Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\Email', 'Cake\Network\Email\Email');
